package Modelo;

/**
 * Orden de cocina. El código (O-01, O-02...) lo asigna el gestor.
 *
 * @author Alexito-Hub
 */
public class Orden {

    private final String codigo;
    private final String cliente;
    private final String platillo;
    private final double monto;
    private final String modalidad;
    private final String hora;

    public Orden(String codigo, String cliente, String platillo, double monto,
            String modalidad, String hora) {
        if (monto <= 0) {
            throw new IllegalArgumentException("El monto debe ser positivo.");
        }
        this.codigo = codigo;
        this.cliente = cliente;
        this.platillo = platillo;
        this.monto = monto;
        this.modalidad = modalidad;
        this.hora = hora;
    }

    public String getCodigo() {
        return codigo;
    }

    public String getCliente() {
        return cliente;
    }

    public String getPlatillo() {
        return platillo;
    }

    public double getMonto() {
        return monto;
    }

    public String getModalidad() {
        return modalidad;
    }

    public String getHora() {
        return hora;
    }

    @Override
    public String toString() {
        return String.format("%s  %-8s %-18s S/ %6.2f  %-11s %s", codigo, cliente, platillo,
                monto, modalidad, hora);
    }
}
