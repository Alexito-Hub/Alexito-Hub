package Modelo;

/**
 * Eslabón de la cola de cocina: una Orden (dato) y el enlace a la siguiente.
 *
 * @author Alexito-Hub
 */
public class NodoOrden {

    private final Orden orden;
    private NodoOrden enlace;

    public NodoOrden(Orden orden) {
        this.orden = orden;
    }

    public Orden getOrden() {
        return orden;
    }

    public NodoOrden getEnlace() {
        return enlace;
    }

    public void setEnlace(NodoOrden enlace) {
        this.enlace = enlace;
    }
}
