package DAO;

import Modelo.NodoOrden;
import Modelo.Orden;

/**
 * Cola dinámica de órdenes de cocina.
 * primero = orden más antigua (se prepara antes); ultimo = orden más reciente.
 * Devuelve null / false en los casos límite en lugar de lanzar excepciones.
 *
 * @author Alexito-Hub
 */
public class GestorPedidos {

    private NodoOrden nodoPrimero;
    private NodoOrden nodoUltimo;
    private int ordenesPendientes;
    private int contadorCorrelativo;

    /** 5. ¿La cocina no tiene órdenes ordenesPendientes? */
    public boolean sinOrdenes() {
        return nodoPrimero == null;
    }

    public int getPendientes() {
        return ordenesPendientes;
    }

    /** 1. Registra la orden al final con un código contadorCorrelativo. */
    public Orden registrarOrden(String cliente, String platillo, double monto,
            String modalidad, String hora) {
        Orden orden = new Orden(String.format("O-%02d", ++contadorCorrelativo), cliente, platillo,
                monto, modalidad, hora);
        NodoOrden nodoNuevo = new NodoOrden(orden);
        if (nodoUltimo == null) {
            nodoPrimero = nodoNuevo;
        } else {
            nodoUltimo.setEnlace(nodoNuevo);
        }
        nodoUltimo = nodoNuevo;
        ordenesPendientes++;
        return orden;
    }

    /** 2. Despacha la orden más antigua. @return null si no hay órdenes. */
    public Orden despacharOrden() {
        if (sinOrdenes()) {
            return null;
        }
        Orden ordenDespachada = nodoPrimero.getOrden();
        nodoPrimero = nodoPrimero.getEnlace();
        if (nodoPrimero == null) {
            nodoUltimo = null;
        }
        ordenesPendientes--;
        return ordenDespachada;
    }

    /** 3. Muestra la próxima orden sin retirarla (Peek). */
    public Orden verProximaOrden() {
        return sinOrdenes() ? null : nodoPrimero.getOrden();
    }

    /** 4. Lista las órdenes ordenesPendientes en orden de llegada. */
    public void listarOrdenes() {
        int turnoEnCola = 1;
        for (NodoOrden nodoActual = nodoPrimero; nodoActual != null; nodoActual = nodoActual.getEnlace()) {
            System.out.printf("  %d. %s%n", turnoEnCola++, nodoActual.getOrden());
        }
    }

    /** 6. Busca por código o cliente. @return la orden o null. */
    public Orden buscarOrden(String criterio) {
        NodoOrden nodoActual = nodoPrimero;
        while (nodoActual != null && !nodoActual.getOrden().getCodigo().equalsIgnoreCase(criterio)
                && !nodoActual.getOrden().getCliente().equalsIgnoreCase(criterio)) {
            nodoActual = nodoActual.getEnlace();
        }
        return nodoActual == null ? null : nodoActual.getOrden();
    }

    /** 7. Suma los montos de todas las órdenes en espera. */
    public double montoAcumulado() {
        double montoTotal = 0;
        for (NodoOrden nodoActual = nodoPrimero; nodoActual != null; nodoActual = nodoActual.getEnlace()) {
            montoTotal += nodoActual.getOrden().getMonto();
        }
        return montoTotal;
    }

    /** 8. Anula una orden por código usando un nodo nodoCentinela. */
    public Orden anularOrden(String codigo) {
        NodoOrden nodoCentinela = new NodoOrden(null);   // nodo auxiliar antes del primero
        nodoCentinela.setEnlace(nodoPrimero);
        NodoOrden nodoPrevio = nodoCentinela;
        while (nodoPrevio.getEnlace() != null
                && !nodoPrevio.getEnlace().getOrden().getCodigo().equalsIgnoreCase(codigo)) {
            nodoPrevio = nodoPrevio.getEnlace();
        }
        NodoOrden nodoAEliminar = nodoPrevio.getEnlace();
        if (nodoAEliminar == null) {
            return null;
        }
        nodoPrevio.setEnlace(nodoAEliminar.getEnlace());       // saltar el nodo
        nodoPrimero = nodoCentinela.getEnlace();
        if (nodoAEliminar == nodoUltimo) {
            nodoUltimo = (nodoPrevio == nodoCentinela) ? null : nodoPrevio;
        }
        ordenesPendientes--;
        return nodoAEliminar.getOrden();
    }
}
