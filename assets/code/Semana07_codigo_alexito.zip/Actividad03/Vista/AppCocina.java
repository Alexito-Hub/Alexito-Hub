package Vista;

import DAO.GestorPedidos;
import Modelo.Orden;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.Scanner;

/**
 * SEMANA 07 - COLAS
 * Actividad 03: control de órdenes de cocina con cola dinámica.
 *
 * @author Alexito-Hub
 */
public class AppCocina {

    private static final Scanner lectorTeclado = new Scanner(System.in).useLocale(Locale.US);
    private static final GestorPedidos cocina = new GestorPedidos();
    private static final String[] MODALIDADES = {"Salon", "Delivery", "Para llevar"};

    public static void main(String[] args) {
        menu();
    }

    // MENÚ PRINCIPAL
    static void menu() {
        int opcionElegida;
        do {
            System.out.println("\n+----------- COCINA - ORDENES -----------+");
            System.out.println("| 1 Nueva orden        2 Despachar       |");
            System.out.println("| 3 Proxima orden      4 Ver pendientes  |");
            System.out.println("| 5 Cocina libre?      6 Buscar orden    |");
            System.out.println("| 7 Monto acumulado    8 Anular orden    |");
            System.out.println("| 9 Salir             99 Datos de prueba |");
            System.out.println("+----------------------------------------+");
            opcionElegida = pedirEntero("Opcion: ");
            switch (opcionElegida) {
                case 1 -> nuevaOrden();
                case 2 -> {
                    Orden orden = cocina.despacharOrden();
                    System.out.println(orden == null ? "UNDERFLOW: no hay ordenes." : "Despachada: " + orden);
                }
                case 3 -> {
                    Orden orden = cocina.verProximaOrden();
                    System.out.println(orden == null ? "No hay ordenes pendientes." : "Se prepara: " + orden);
                }
                case 4 -> verPendientes();
                case 5 -> System.out.println(cocina.sinOrdenes() ? "Cocina libre: 0 ordenes."
                        : cocina.getPendientes() + " orden(es) en espera.");
                case 6 -> {
                    Orden orden = cocina.buscarOrden(pedirTexto("Codigo o cliente: "));
                    System.out.println(orden == null ? "Sin resultados." : "Encontrada: " + orden);
                }
                case 7 -> System.out.printf("Monto acumulado: S/ %.2f en %d orden(es)%n",
                        cocina.montoAcumulado(), cocina.getPendientes());
                case 8 -> {
                    Orden orden = cocina.anularOrden(pedirTexto("Codigo a anular: "));
                    System.out.println(orden == null ? "Codigo no encontrado." : "Anulada: " + orden.getCodigo());
                }
                case 9 -> System.out.println("Cocina cerrada.");
                case 99 -> cargarDemo();
                default -> System.out.println("Opcion inexistente.");
            }
        } while (opcionElegida != 9);
    }

    static void nuevaOrden() {
        String cliente = pedirTexto("Cliente: ");
        String platillo = pedirTexto("Platillo: ");
        double monto = pedirMonto();
        for (int indice = 0; indice < MODALIDADES.length; indice++) {
            System.out.println("  " + (indice + 1) + ") " + MODALIDADES[indice]);
        }
        int opcionModalidad;
        do {
            opcionModalidad = pedirEntero("Modalidad: ");
        } while (opcionModalidad < 1 || opcionModalidad > MODALIDADES.length);
        String hora = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"));
        Orden orden = cocina.registrarOrden(cliente, platillo, monto, MODALIDADES[opcionModalidad - 1], hora);
        System.out.println("Orden registrada: " + orden.getCodigo());
    }

    static void verPendientes() {
        if (cocina.sinOrdenes()) {
            System.out.println("No hay ordenes pendientes.");
            return;
        }
        System.out.println("PRIMERO (se prepara antes)");
        cocina.listarOrdenes();
        System.out.println("ULTIMO");
    }

    static void cargarDemo() {
        cocina.registrarOrden("Pedro", "Pollo a la brasa", 45.00, "Delivery", "19:02");
        cocina.registrarOrden("Elena", "Tallarines verdes", 24.50, "Salon", "19:06");
        cocina.registrarOrden("Raul", "Causa limena", 18.00, "Para llevar", "19:11");
        cocina.registrarOrden("Sonia", "Chicharron", 32.00, "Salon", "19:15");
        cocina.registrarOrden("Marco", "Anticuchos", 27.50, "Delivery", "19:20");
        System.out.println("5 ordenes de prueba registradas.");
    }

    // ------------- lectura validada -------------
    static double pedirMonto() {
        while (true) {
            System.out.print("Monto S/: ");
            if (lectorTeclado.hasNextDouble()) {
                double valorIngresado = lectorTeclado.nextDouble();
                lectorTeclado.nextLine();
                if (valorIngresado > 0) {
                    return valorIngresado;
                }
            } else {
                lectorTeclado.nextLine();
            }
            System.out.println("El monto debe ser un numero positivo.");
        }
    }

    static int pedirEntero(String mensajeSolicitud) {
        while (true) {
            System.out.print(mensajeSolicitud);
            if (lectorTeclado.hasNextInt()) {
                int valorIngresado = lectorTeclado.nextInt();
                lectorTeclado.nextLine();
                return valorIngresado;
            }
            lectorTeclado.nextLine();
            System.out.println("Escriba un numero.");
        }
    }

    static String pedirTexto(String mensajeSolicitud) {
        String textoIngresado;
        do {
            System.out.print(mensajeSolicitud);
            textoIngresado = lectorTeclado.nextLine().trim();
        } while (textoIngresado.isEmpty());
        return textoIngresado;
    }
}
