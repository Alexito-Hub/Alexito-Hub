package Modelo;

/**
 * Eslabón de la cola dinámica: guarda un Ticket (dato) y apunta al siguiente (enlace).
 *
 * @author Alexito-Hub
 */
public class NodoTicket {

    private final Ticket ticket;
    private NodoTicket enlace;

    public NodoTicket(Ticket ticket) {
        this.ticket = ticket;
        this.enlace = null;
    }

    public Ticket getTicket() {
        return ticket;
    }

    public NodoTicket getEnlace() {
        return enlace;
    }

    public void setEnlace(NodoTicket enlace) {
        this.enlace = enlace;
    }
}
