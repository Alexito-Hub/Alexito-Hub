package Modelo;

/**
 * Turno de atención bancaria. El número se asigna automáticamente (T-001, T-002...).
 *
 * @author Alexito-Hub
 */
public class Ticket {

    /** Tipos de trámite que acepta la ventanilla. */
    public static final String[] TRAMITES = {"Deposito", "Retiro", "Reclamo"};

    private final String numero;
    private final String dni;
    private final String cliente;
    private final String tramite;
    private final boolean preferencial;
    private final String hora;

    public Ticket(String numero, String dni, String cliente, String tramite,
            boolean preferencial, String hora) {
        this.numero = numero;
        this.dni = dni;
        this.cliente = cliente;
        this.tramite = tramite;
        this.preferencial = preferencial;
        this.hora = hora;
    }

    public String getNumero() {
        return numero;
    }

    public String getDni() {
        return dni;
    }

    public String getCliente() {
        return cliente;
    }

    public String getTramite() {
        return tramite;
    }

    public boolean isPreferencial() {
        return preferencial;
    }

    public String getHora() {
        return hora;
    }

    /** ¿El ticket corresponde a este número o DNI? */
    public boolean coincideCon(String criterio) {
        return numero.equalsIgnoreCase(criterio) || dni.equals(criterio);
    }

    @Override
    public String toString() {
        return String.format("%s  %-16s DNI %s  %-9s %-13s %s", numero, cliente, dni, tramite,
                preferencial ? "PREFERENCIAL" : "normal", hora);
    }
}
