package Vista;

import DAO.GestorTurnos;
import Modelo.Ticket;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

/**
 * SEMANA 07 - COLAS
 * Actividad 02: turnos de ventanilla bancaria con cola dinámica.
 *
 * @author Alexito-Hub
 */
public class AppBanco {

    private static final Scanner lectorTeclado = new Scanner(System.in);
    private static final GestorTurnos turnos = new GestorTurnos();

    public static void main(String[] args) {
        menu();
    }

    // MENÚ PRINCIPAL
    static void menu() {
        int opcionElegida;
        do {
            System.out.println("\n+---------- VENTANILLA - TURNOS ----------+");
            System.out.println("| 1 Sacar ticket       2 Atender cliente  |");
            System.out.println("| 3 Siguiente turno    4 Ver cola         |");
            System.out.println("| 5 Cola vacia?        6 Buscar ticket/DNI|");
            System.out.println("| 7 Reporte tramite    8 Cancelar turno   |");
            System.out.println("| 9 Salir             99 Datos de prueba  |");
            System.out.println("+-----------------------------------------+");
            opcionElegida = pedirEntero("Opcion: ");
            switch (opcionElegida) {
                case 1 -> sacarTicket();
                case 2 -> atender();
                case 3 -> siguiente();
                case 4 -> verCola();
                case 5 -> System.out.println(turnos.sinTurnos() ? "No hay clientes en espera."
                        : turnos.getClientesEnEspera() + " cliente(s) en espera.");
                case 6 -> buscar();
                case 7 -> reporte();
                case 8 -> cancelar();
                case 9 -> System.out.println("Ventanilla cerrada.");
                case 99 -> cargarDemo();
                default -> System.out.println("Opcion inexistente.");
            }
        } while (opcionElegida != 9);
    }

    static void sacarTicket() {
        String dni = pedirDni();
        if (turnos.buscarTurno(dni) != -1) {
            System.out.println("Ese DNI ya tiene un turno en la cola.");
            return;
        }
        String cliente = pedirTexto("Nombre del cliente: ");
        String tramite = elegirTramite();
        boolean preferencial = pedirTexto("Preferencial? (S/N): ").equalsIgnoreCase("S");
        String hora = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"));
        Ticket ticket = turnos.registrarTurno(dni, cliente, tramite, preferencial, hora);
        System.out.println("Ticket emitido: " + ticket.getNumero() + " (" + turnos.getClientesEnEspera() + " en espera)");
    }

    static void atender() {
        Ticket ticket = turnos.atenderTurno();
        System.out.println(ticket == null ? "UNDERFLOW: no hay clientes por atender." : "Atendiendo: " + ticket);
    }

    static void siguiente() {
        Ticket ticket = turnos.verSiguienteTurno();
        System.out.println(ticket == null ? "No hay turnos pendientes." : "Siguiente: " + ticket);
    }

    static void verCola() {
        if (turnos.sinTurnos()) {
            System.out.println("La cola de espera esta vacia.");
            return;
        }
        System.out.println("CABEZA (se atiende primero)");
        turnos.listarEspera();
        System.out.println("COLA (ultimo en llegar)");
    }

    static void buscar() {
        String criterio = pedirTexto("Ticket o DNI: ");
        int lugarEnFila = turnos.buscarTurno(criterio);
        System.out.println(lugarEnFila == -1 ? "Sin resultados para " + criterio + "."
                : "Lugar " + lugarEnFila + " en la fila: " + turnos.ticketEnLugar(lugarEnFila));
    }

    static void reporte() {
        String tramite = elegirTramite();
        int cantidadDelTramite = turnos.reportePorTramite(tramite);
        System.out.println(cantidadDelTramite + " turno(s) de " + tramite + ".");
    }

    static void cancelar() {
        Ticket ticket = turnos.cancelarTurno(pedirTexto("Numero de ticket a cancelar: "));
        System.out.println(ticket == null ? "Ticket no encontrado." : "Turno cancelado: " + ticket.getNumero());
    }

    static void cargarDemo() {
        turnos.registrarTurno("70582147", "Luis Condori", "Reclamo", false, "09:02");
        turnos.registrarTurno("73698521", "Fiorella Ramos", "Retiro", true, "09:07");
        turnos.registrarTurno("72014785", "Hector Quispe", "Deposito", false, "09:15");
        turnos.registrarTurno("74859632", "Daniela Ortiz", "Reclamo", true, "09:21");
        turnos.registrarTurno("71236548", "Ricardo Mamani", "Retiro", false, "09:28");
        System.out.println("5 turnos de prueba registrados.");
    }

    // ------------- lectura validada -------------
    static String elegirTramite() {
        for (int indice = 0; indice < Ticket.TRAMITES.length; indice++) {
            System.out.println("  " + (indice + 1) + ") " + Ticket.TRAMITES[indice]);
        }
        int opcionTramite;
        do {
            opcionTramite = pedirEntero("Tramite: ");
        } while (opcionTramite < 1 || opcionTramite > Ticket.TRAMITES.length);
        return Ticket.TRAMITES[opcionTramite - 1];
    }

    static String pedirDni() {
        String dni;
        do {
            dni = pedirTexto("DNI (8 digitos): ");
        } while (!dni.matches("\\d{8}"));
        return dni;
    }

    static int pedirEntero(String mensajeSolicitud) {
        while (true) {
            System.out.print(mensajeSolicitud);
            if (lectorTeclado.hasNextInt()) {
                int valorIngresado = lectorTeclado.nextInt();
                lectorTeclado.nextLine();
                return valorIngresado;
            }
            lectorTeclado.nextLine();
            System.out.println("Escriba un numero.");
        }
    }

    static String pedirTexto(String mensajeSolicitud) {
        String textoIngresado;
        do {
            System.out.print(mensajeSolicitud);
            textoIngresado = lectorTeclado.nextLine().trim();
        } while (textoIngresado.isEmpty());
        return textoIngresado;
    }
}
