package DAO;

import Modelo.NodoTicket;
import Modelo.Ticket;

/**
 * Cola dinámica de turnos bancarios con dos punteros:
 * cabeza (siguiente en ser nodoAtendido) y cola (último en llegar).
 * El gestor genera el número de ticket con un contador contadorCorrelativo.
 *
 * @author Alexito-Hub
 */
public class GestorTurnos {

    private NodoTicket nodoCabeza;
    private NodoTicket nodoCola;
    private int clientesEnEspera;
    private int contadorCorrelativo;

    public GestorTurnos() {
        nodoCabeza = nodoCola = null;
        clientesEnEspera = 0;
        contadorCorrelativo = 0;
    }

    /** 5. ¿No quedan clientes por atender? */
    public boolean sinTurnos() {
        return nodoCabeza == null;
    }

    public int getClientesEnEspera() {
        return clientesEnEspera;
    }

    /** 1. Crea el ticket con número contadorCorrelativo y lo enlaza al final. */
    public Ticket registrarTurno(String dni, String cliente, String tramite,
            boolean preferencial, String hora) {
        contadorCorrelativo++;
        Ticket ticketNuevo = new Ticket(String.format("T-%03d", contadorCorrelativo), dni, cliente,
                tramite, preferencial, hora);
        NodoTicket nodoNuevo = new NodoTicket(ticketNuevo);
        if (sinTurnos()) {
            nodoCabeza = nodoNuevo;          // primer cliente: es cabeza y cola
        } else {
            nodoCola.setEnlace(nodoNuevo);   // el último apunta al nuevo
        }
        nodoCola = nodoNuevo;
        clientesEnEspera++;
        return ticketNuevo;
    }

    /** 2. Atiende al cliente de la cabeza. @return null si no hay turnos. */
    public Ticket atenderTurno() {
        if (sinTurnos()) {
            return null;
        }
        NodoTicket nodoAtendido = nodoCabeza;
        nodoCabeza = nodoAtendido.getEnlace();
        nodoAtendido.setEnlace(null);   // se suelta el nodo para el recolector
        if (nodoCabeza == null) {
            nodoCola = null;
        }
        clientesEnEspera--;
        return nodoAtendido.getTicket();
    }

    /** 3. Muestra quién sigue sin sacarlo de la cola. */
    public Ticket verSiguienteTurno() {
        return sinTurnos() ? null : nodoCabeza.getTicket();
    }

    /** 4. Lista la cola de espera de la cabeza a la cola. */
    public void listarEspera() {
        int lugarEnFila = 1;
        for (NodoTicket nodoActual = nodoCabeza; nodoActual != null; nodoActual = nodoActual.getEnlace()) {
            System.out.printf("  %2d. %s%n", lugarEnFila++, nodoActual.getTicket());
        }
    }

    /** 6. Busca por número de ticket o DNI. @return lugar en la fila o -1. */
    public int buscarTurno(String criterio) {
        int lugarEnFila = 1;
        for (NodoTicket nodoActual = nodoCabeza; nodoActual != null; nodoActual = nodoActual.getEnlace()) {
            if (nodoActual.getTicket().coincideCon(criterio)) {
                return lugarEnFila;
            }
            lugarEnFila++;
        }
        return -1;
    }

    /** Devuelve el ticket que está en el lugar indicado (1 = cabeza). */
    public Ticket ticketEnLugar(int lugarEnFila) {
        NodoTicket nodoActual = nodoCabeza;
        for (int contador = 1; contador < lugarEnFila && nodoActual != null; contador++) {
            nodoActual = nodoActual.getEnlace();
        }
        return nodoActual == null ? null : nodoActual.getTicket();
    }

    /** 7. Reporte de los turnos de un trámite. @return cuántos hay. */
    public int reportePorTramite(String tramite) {
        int cantidadDelTramite = 0;
        for (NodoTicket nodoActual = nodoCabeza; nodoActual != null; nodoActual = nodoActual.getEnlace()) {
            if (nodoActual.getTicket().getTramite().equalsIgnoreCase(tramite)) {
                System.out.println("  " + nodoActual.getTicket());
                cantidadDelTramite++;
            }
        }
        return cantidadDelTramite;
    }

    /** 8. Cancela un turno por número: reenlaza al anterior con el siguiente. */
    public Ticket cancelarTurno(String numero) {
        NodoTicket nodoPrevio = null;
        NodoTicket nodoActual = nodoCabeza;
        while (nodoActual != null && !nodoActual.getTicket().getNumero().equalsIgnoreCase(numero)) {
            nodoPrevio = nodoActual;
            nodoActual = nodoActual.getEnlace();
        }
        if (nodoActual == null) {
            return null;                         // no existe
        }
        if (nodoPrevio == null) {
            nodoCabeza = nodoActual.getEnlace();         // era la cabeza
        } else {
            nodoPrevio.setEnlace(nodoActual.getEnlace()); // puente sobre el nodo
        }
        if (nodoActual == nodoCola) {
            nodoCola = nodoPrevio;                       // era el último
        }
        clientesEnEspera--;
        return nodoActual.getTicket();
    }
}
