package DAO;

import Modelo.Alumno;

/**
 * Cola circular estática de alumnos.
 * <ul>
 *   <li>indiceFrente: posición del alumno que sale primero.</li>
 *   <li>indiceFinal: siguiente casilla libre donde entra el próximo alumno.</li>
 *   <li>cantidadAlumnos: alumnos almacenados.</li>
 * </ul>
 * Las operaciones no lanzan excepciones: devuelven false / null y la Vista informa.
 *
 * @author Alexito-Hub
 */
public class GestorColaAlumnos {

    private final Alumno[] arregloAlumnos;
    private int indiceFrente;
    private int indiceFinal;
    private int cantidadAlumnos;

    public GestorColaAlumnos(int capacidad) {
        arregloAlumnos = new Alumno[Math.max(1, capacidad)];
        indiceFrente = 0;
        indiceFinal = 0;
        cantidadAlumnos = 0;
    }

    /** @return true si no hay alumnos (evita Underflow). */
    public boolean colaVacia() {
        return cantidadAlumnos == 0;
    }

    /** @return true si se alcanzó la capacidad (evita Overflow). */
    public boolean colaLlena() {
        return cantidadAlumnos == arregloAlumnos.length;
    }

    public int getCantidad() {
        return cantidadAlumnos;
    }

    public int getCapacidad() {
        return arregloAlumnos.length;
    }

    /** Posición física del alumno que ocupa el lugar relativo indicado de la fila (0 = frente). */
    private int posicionFisica(int lugarRelativo) {
        return (indiceFrente + lugarRelativo) % arregloAlumnos.length;
    }

    /** a) Encola al final. @return false si la cola está llena. */
    public boolean encolar(Alumno alumno) {
        if (colaLlena()) {
            return false;
        }
        arregloAlumnos[indiceFinal] = alumno;
        indiceFinal = (indiceFinal + 1) % arregloAlumnos.length;
        cantidadAlumnos++;
        return true;
    }

    /** b) Desencola el frente. @return el alumno o null si está vacía. */
    public Alumno desencolar() {
        if (colaVacia()) {
            return null;
        }
        Alumno alumnoSaliente = arregloAlumnos[indiceFrente];
        arregloAlumnos[indiceFrente] = null;
        indiceFrente = (indiceFrente + 1) % arregloAlumnos.length;
        cantidadAlumnos--;
        return alumnoSaliente;
    }

    /** c) Devuelve el frente sin quitarlo (null si está vacía). */
    public Alumno verFrente() {
        return colaVacia() ? null : arregloAlumnos[indiceFrente];
    }

    /** d) Lista los alumnos del frente al final (FIFO). */
    public void listar() {
        for (int lugarRelativo = 0; lugarRelativo < cantidadAlumnos; lugarRelativo++) {
            System.out.printf("  %d) %s%n", lugarRelativo + 1, arregloAlumnos[posicionFisica(lugarRelativo)]);
        }
    }

    /** 1. Busca por código recorriendo los índices: la cola no se modifica. */
    public int buscarAlumno(String codigo) {
        for (int lugarRelativo = 0; lugarRelativo < cantidadAlumnos; lugarRelativo++) {
            if (arregloAlumnos[posicionFisica(lugarRelativo)].getCodigo().equalsIgnoreCase(codigo.trim())) {
                return lugarRelativo + 1; // lugar en la fila (1 = frente)
            }
        }
        return -1;
    }

    /** Devuelve el alumno que ocupa el lugar indicado (1 = frente). */
    public Alumno alumnoEnLugar(int lugarEnFila) {
        return arregloAlumnos[posicionFisica(lugarEnFila - 1)];
    }

    /** 2. Media aritmética de los promedios del grupo. */
    public double promedioGrupo() {
        double sumaPromedios = 0;
        for (int lugarRelativo = 0; lugarRelativo < cantidadAlumnos; lugarRelativo++) {
            sumaPromedios += arregloAlumnos[posicionFisica(lugarRelativo)].getPromedio();
        }
        return cantidadAlumnos == 0 ? 0 : sumaPromedios / cantidadAlumnos;
    }

    /** 3. Imprime y cuenta los alumnos con promedio >= notaMinima. */
    public int filtrarPorNota(double notaMinima) {
        int alumnosQueCumplen = 0;
        for (int lugarRelativo = 0; lugarRelativo < cantidadAlumnos; lugarRelativo++) {
            Alumno alumnoActual = arregloAlumnos[posicionFisica(lugarRelativo)];
            if (alumnoActual.getPromedio() >= notaMinima) {
                System.out.println("  " + alumnoActual);
                alumnosQueCumplen++;
            }
        }
        return alumnosQueCumplen;
    }

    /** 4. Devuelve {mayor, menor} promedio en un solo recorrido. */
    public Alumno[] obtenerExtremos() {
        if (colaVacia()) {
            return null;
        }
        Alumno alumnoMejorPromedio = arregloAlumnos[indiceFrente];
        Alumno alumnoPeorPromedio = arregloAlumnos[indiceFrente];
        for (int lugarRelativo = 1; lugarRelativo < cantidadAlumnos; lugarRelativo++) {
            Alumno alumnoActual = arregloAlumnos[posicionFisica(lugarRelativo)];
            if (alumnoActual.getPromedio() > alumnoMejorPromedio.getPromedio()) alumnoMejorPromedio = alumnoActual;
            if (alumnoActual.getPromedio() < alumnoPeorPromedio.getPromedio()) alumnoPeorPromedio = alumnoActual;
        }
        return new Alumno[] {alumnoMejorPromedio, alumnoPeorPromedio};
    }

    /** 5. Invierte la cola apilando todo en una pila (LIFO) y volviendo a encolar. */
    public void invertirOrden() {
        Alumno[] pilaAuxiliar = new Alumno[cantidadAlumnos];
        int cimaAuxiliar = 0;
        while (!colaVacia()) {
            pilaAuxiliar[cimaAuxiliar++] = desencolar();
        }
        while (cimaAuxiliar > 0) {
            encolar(pilaAuxiliar[--cimaAuxiliar]);
        }
    }

    /** 6. Da de baja por código desplazando a los que estaban detrás. */
    public Alumno darDeBaja(String codigo) {
        int lugarEnFila = buscarAlumno(codigo);
        if (lugarEnFila == -1) {
            return null;
        }
        Alumno alumnoRetirado = arregloAlumnos[posicionFisica(lugarEnFila - 1)];
        for (int lugarRelativo = lugarEnFila - 1; lugarRelativo < cantidadAlumnos - 1; lugarRelativo++) {
            // correr un lugar hacia el frente
            arregloAlumnos[posicionFisica(lugarRelativo)] =
                    arregloAlumnos[posicionFisica(lugarRelativo + 1)];
        }
        indiceFinal = (indiceFinal - 1 + arregloAlumnos.length) % arregloAlumnos.length;
        arregloAlumnos[indiceFinal] = null;
        cantidadAlumnos--;
        return alumnoRetirado;
    }
}
