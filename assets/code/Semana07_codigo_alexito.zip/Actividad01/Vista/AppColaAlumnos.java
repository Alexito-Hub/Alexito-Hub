package Vista;

import DAO.GestorColaAlumnos;
import Modelo.Alumno;
import java.util.Locale;
import java.util.Scanner;

/**
 * SEMANA 07 - COLAS
 * Actividad 01: cola circular de alumnos (Modelo / DAO / Vista).
 *
 * @author Alexito-Hub
 */
public class AppColaAlumnos {

    private static final Scanner lectorTeclado = new Scanner(System.in).useLocale(Locale.US);
    private static GestorColaAlumnos gestor;

    public static void main(String[] args) {
        System.out.println(">> COLA DE ALUMNOS (FIFO) <<");
        gestor = new GestorColaAlumnos(pedirEntero("Capacidad de la cola (>= 1): ", 1, 500));
        menu();
    }

    // MENÚ PRINCIPAL
    static void menu() {
        int opcionElegida;
        do {
            System.out.println("\n+-------------- COLA DE ALUMNOS --------------+");
            System.out.println("|  1 Encolar        2 Desencolar    3 Frente   |");
            System.out.println("|  4 Listar         5 Vacia?        6 Llena?   |");
            System.out.println("|  7 Cantidad                                  |");
            System.out.println("|  8 Buscar codigo  9 Promedio grupo           |");
            System.out.println("| 10 Filtrar nota  11 Mayor/menor  12 Invertir |");
            System.out.println("| 13 Dar de baja   99 Datos prueba  0 Salir    |");
            System.out.println("+----------------------------------------------+");
            opcionElegida = pedirEntero("Opcion: ", 0, 99);
            switch (opcionElegida) {
                case 1 -> opcionEncolar();
                case 2 -> opcionDesencolar();
                case 3 -> opcionFrente();
                case 4 -> opcionListar();
                case 5 -> System.out.println(gestor.colaVacia() ? "Si, la cola esta vacia." : "No, hay alumnos esperando.");
                case 6 -> System.out.println(gestor.colaLlena() ? "Si, la cola esta llena." : "No, aun hay espacio.");
                case 7 -> System.out.printf("Ocupados: %d / %d  (libres: %d)%n", gestor.getCantidad(),
                        gestor.getCapacidad(), gestor.getCapacidad() - gestor.getCantidad());
                case 8 -> opcionBuscar();
                case 9 -> opcionPromedio();
                case 10 -> opcionFiltrar();
                case 11 -> opcionExtremos();
                case 12 -> opcionInvertir();
                case 13 -> opcionDarDeBaja();
                case 99 -> cargarDemo();
                case 0 -> System.out.println("Hasta luego.");
                default -> System.out.println("Opcion inexistente.");
            }
        } while (opcionElegida != 0);
    }

    static void opcionEncolar() {
        if (gestor.colaLlena()) {
            System.out.println("OVERFLOW: no hay espacio en la cola.");
            return;
        }
        String codigo = pedirTexto("Codigo: ");
        if (gestor.buscarAlumno(codigo) != -1) {
            System.out.println("Ese codigo ya esta en la cola.");
            return;
        }
        try {
            Alumno alumnoNuevo = new Alumno(codigo, pedirTexto("Nombre: "), pedirEntero("Edad: ", 15, 80),
                    pedirDecimal("Promedio: ", 0, 20));
            gestor.encolar(alumnoNuevo);
            System.out.println("Encolado al final: " + alumnoNuevo);
        } catch (IllegalArgumentException excepcion) {
            System.out.println("Dato invalido: " + excepcion.getMessage());
        }
    }

    static void opcionDesencolar() {
        Alumno alumnoSaliente = gestor.desencolar();
        System.out.println(alumnoSaliente == null ? "UNDERFLOW: la cola esta vacia." : "Sale de la cola: " + alumnoSaliente);
    }

    static void opcionFrente() {
        Alumno alumnoFrente = gestor.verFrente();
        System.out.println(alumnoFrente == null ? "La cola esta vacia." : "En el frente: " + alumnoFrente);
    }

    static void opcionListar() {
        if (gestor.colaVacia()) {
            System.out.println("La cola esta vacia.");
            return;
        }
        System.out.println("FRENTE");
        gestor.listar();
        System.out.println("FINAL");
    }

    static void opcionBuscar() {
        String codigo = pedirTexto("Codigo a buscar: ");
        int lugarEnFila = gestor.buscarAlumno(codigo);
        if (lugarEnFila == -1) {
            System.out.println("No se encontro el codigo " + codigo + ".");
        } else {
            System.out.println("Lugar " + lugarEnFila + " en la fila: " + gestor.alumnoEnLugar(lugarEnFila));
        }
    }

    static void opcionPromedio() {
        if (gestor.colaVacia()) {
            System.out.println("La cola esta vacia.");
            return;
        }
        System.out.printf("Promedio del grupo: %.2f%n", gestor.promedioGrupo());
    }

    static void opcionFiltrar() {
        double notaMinima = pedirDecimal("Nota minima: ", 0, 20);
        int cantidadQueCumple = gestor.filtrarPorNota(notaMinima);
        System.out.println(cantidadQueCumple + " alumno(s) con promedio >= " + notaMinima);
    }

    static void opcionExtremos() {
        Alumno[] alumnosExtremos = gestor.obtenerExtremos();
        if (alumnosExtremos == null) {
            System.out.println("La cola esta vacia.");
            return;
        }
        System.out.println("Mayor promedio: " + alumnosExtremos[0]);
        System.out.println("Menor promedio: " + alumnosExtremos[1]);
    }

    static void opcionInvertir() {
        if (gestor.getCantidad() < 2) {
            System.out.println("Se necesitan al menos 2 alumnos.");
            return;
        }
        gestor.invertirOrden();
        System.out.println("Cola invertida (pila auxiliar):");
        opcionListar();
    }

    static void opcionDarDeBaja() {
        Alumno alumnoRetirado = gestor.darDeBaja(pedirTexto("Codigo a dar de baja: "));
        System.out.println(alumnoRetirado == null ? "Codigo no encontrado." : "Dado de baja: " + alumnoRetirado);
    }

    static void cargarDemo() {
        Alumno[] alumnosDemostracion = {
            new Alumno("B201", "Mateo", 21, 15.0),
            new Alumno("B202", "Lucia", 19, 17.6),
            new Alumno("B203", "Bruno", 23, 12.4),
            new Alumno("B204", "Andrea", 20, 16.8),
            new Alumno("B205", "Joaquin", 18, 14.9)
        };
        int alumnosAgregados = 0;
        for (Alumno alumnoDemo : alumnosDemostracion) {
            if (gestor.buscarAlumno(alumnoDemo.getCodigo()) == -1 && gestor.encolar(alumnoDemo)) {
                alumnosAgregados++;
            }
        }
        System.out.println("Alumnos de prueba encolados: " + alumnosAgregados);
    }

    // ------------- lectura validada -------------
    static int pedirEntero(String mensajeSolicitud, int minimoPermitido, int maximoPermitido) {
        while (true) {
            System.out.print(mensajeSolicitud);
            if (lectorTeclado.hasNextInt()) {
                int valorIngresado = lectorTeclado.nextInt();
                lectorTeclado.nextLine();
                if (valorIngresado >= minimoPermitido && valorIngresado <= maximoPermitido) {
                    return valorIngresado;
                }
            } else {
                lectorTeclado.nextLine();
            }
            System.out.println("Valor fuera de rango (" + minimoPermitido + " - " + maximoPermitido + ").");
        }
    }

    static double pedirDecimal(String mensajeSolicitud, double minimoPermitido, double maximoPermitido) {
        while (true) {
            System.out.print(mensajeSolicitud);
            if (lectorTeclado.hasNextDouble()) {
                double valorIngresado = lectorTeclado.nextDouble();
                lectorTeclado.nextLine();
                if (valorIngresado >= minimoPermitido && valorIngresado <= maximoPermitido) {
                    return valorIngresado;
                }
            } else {
                lectorTeclado.nextLine();
            }
            System.out.println("Ingrese un decimal entre " + minimoPermitido + " y " + maximoPermitido + ".");
        }
    }

    static String pedirTexto(String mensajeSolicitud) {
        String textoIngresado;
        do {
            System.out.print(mensajeSolicitud);
            textoIngresado = lectorTeclado.nextLine().trim();
        } while (textoIngresado.isEmpty());
        return textoIngresado;
    }
}
