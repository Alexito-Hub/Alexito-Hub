package Modelo;

/**
 * Representa a un alumno registrado en la cola.
 * La validación se hace una sola vez en el constructor (objeto inmutable salvo el promedio).
 *
 * @author Alexito-Hub
 */
public class Alumno {

    private final String codigo;
    private final String nombre;
    private final int edad;
    private double promedio;

    /**
     * Crea un alumno validando todos sus datos.
     *
     * @throws IllegalArgumentException si algún dato está fuera de rango
     */
    public Alumno(String codigo, String nombre, int edad, double promedio) {
        if (codigo == null || codigo.isBlank() || nombre == null || nombre.isBlank()) {
            throw new IllegalArgumentException("Codigo y nombre son obligatorios.");
        }
        if (edad < 15 || edad > 80) {
            throw new IllegalArgumentException("Edad fuera de rango (15-80).");
        }
        this.codigo = codigo.trim().toUpperCase();
        this.nombre = nombre.trim();
        this.edad = edad;
        actualizarPromedio(promedio);
    }

    public String getCodigo() {
        return codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public int getEdad() {
        return edad;
    }

    public double getPromedio() {
        return promedio;
    }

    /** Cambia el promedio solo si está entre 0 y 20. */
    public final void actualizarPromedio(double nuevoPromedio) {
        if (nuevoPromedio < 0 || nuevoPromedio > 20) {
            throw new IllegalArgumentException("El promedio debe estar entre 0 y 20.");
        }
        this.promedio = nuevoPromedio;
    }

    @Override
    public String toString() {
        return String.format("[%s] %-10s %2d anios  prom. %5.2f", codigo, nombre, edad, promedio);
    }
}
