package DAO;

import Modelo.PlanProyecto;
import Modelo.Tarea;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** Analiza las dependencias entre tareas con recursividad (recorrido en profundidad del grafo). */
public class GestorDependencias {

    private final PlanProyecto proyecto;

    public GestorDependencias(PlanProyecto proyecto) {
        this.proyecto = proyecto;
    }

    // ---------------------------------------------------------------- RF01
    public void crearTarea(String codigo, String descripcion, boolean completada) {
        if (codigo.isEmpty() || descripcion.isEmpty()) {
            throw new IllegalArgumentException("El codigo y la descripcion no pueden estar vacios.");
        }
        if (proyecto.getMapaTareas().containsKey(codigo)) {
            throw new IllegalArgumentException("Ya existe la tarea " + codigo + ".");
        }
        proyecto.getMapaTareas().put(codigo, new Tarea(codigo, descripcion, completada));
    }

    // ---------------------------------------------------------------- RF02
    /** La tarea {@code codigoTarea} necesita que {@code codigoRequisito} termine primero. */
    public void vincularRequisito(String codigoTarea, String codigoRequisito) {
        Tarea tarea = buscarTarea(codigoTarea);
        buscarTarea(codigoRequisito);
        if (codigoTarea.equals(codigoRequisito)) {
            throw new IllegalArgumentException("Una tarea no puede depender de si misma.");
        }
        if (tarea.getRequisitos().contains(codigoRequisito)) {
            throw new IllegalArgumentException("La dependencia " + codigoTarea + " -> " + codigoRequisito + " ya existe.");
        }
        tarea.getRequisitos().add(codigoRequisito);
    }

    // ---------------------------------------------------------------- RF03
    public List<String> requisitosDirectos(String codigoTarea) {
        return new ArrayList<>(buscarTarea(codigoTarea).getRequisitos());
    }

    // ---------------------------------------------------------------- RF04
    /** Todas las dependencias indirectas: prerrequisitos de los prerrequisitos, y asi sucesivamente. */
    public Set<String> requisitosIndirectos(String codigoTarea) {
        Set<String> requisitosHallados = new LinkedHashSet<>();
        acumularRequisitos(codigoTarea, requisitosHallados);
        return requisitosHallados;
    }

    private void acumularRequisitos(String codigoTarea, Set<String> requisitosHallados) {
        for (String codigoRequisito : buscarTarea(codigoTarea).getRequisitos()) {
            if (requisitosHallados.add(codigoRequisito)) {          // si ya estaba, no se vuelve a recorrer
                acumularRequisitos(codigoRequisito, requisitosHallados);
            }
        }
    }

    // ---------------------------------------------------------------- RF05
    /** Longitud de la cadena mas larga de prerrequisitos (0 si la tarea no depende de nadie). */
    public int nivelMaximo(String codigoTarea) {
        buscarTarea(codigoTarea);
        if (!buscarRutaCiclo().isEmpty()) {
            throw new IllegalStateException("Hay un ciclo de dependencias; la profundidad no esta definida.");
        }
        return calcularNivel(codigoTarea);
    }

    private int calcularNivel(String codigoTarea) {
        List<String> requisitos = buscarTarea(codigoTarea).getRequisitos();
        if (requisitos.isEmpty()) {
            return 0;                                           // caso base: tarea sin prerrequisitos
        }
        return 1 + mayorNivelEntre(requisitos, 0, 0);
    }

    /**
     * Recursividad anidada: el resultado de calcularNivel(...) (llamada interior) se usa como
     * argumento de Math.max(...), y este valor es el argumento de la llamada recursiva exterior.
     */
    private int mayorNivelEntre(List<String> requisitos, int indice, int nivelMayor) {
        if (indice == requisitos.size()) {
            return nivelMayor;                                  // caso base: ya se revisaron todos
        }
        return mayorNivelEntre(requisitos, indice + 1,
                Math.max(nivelMayor, calcularNivel(requisitos.get(indice))));
    }

    // ---------------------------------------------------------------- RF06
    /** Devuelve la ruta del primer ciclo encontrado (ej. [A, B, C, A]) o una lista vacia si no hay. */
    public List<String> buscarRutaCiclo() {
        Set<String> tareasRevisadas = new HashSet<>();
        for (String codigoTarea : proyecto.getMapaTareas().keySet()) {
            List<String> rutaActual = new ArrayList<>();
            if (explorarCiclo(codigoTarea, rutaActual, tareasRevisadas)) {
                return rutaActual;
            }
        }
        return new ArrayList<>();
    }

    private boolean explorarCiclo(String codigoTarea, List<String> rutaActual, Set<String> tareasRevisadas) {
        int lugarEnRuta = rutaActual.indexOf(codigoTarea);
        if (lugarEnRuta >= 0) {                              // volvimos a una tarea que esta explorandose
            rutaActual.subList(0, lugarEnRuta).clear();
            rutaActual.add(codigoTarea);
            return true;
        }
        if (tareasRevisadas.contains(codigoTarea)) {
            return false;
        }
        rutaActual.add(codigoTarea);
        for (String codigoRequisito : buscarTarea(codigoTarea).getRequisitos()) {
            if (explorarCiclo(codigoRequisito, rutaActual, tareasRevisadas)) {
                return true;
            }
        }
        rutaActual.remove(rutaActual.size() - 1);
        tareasRevisadas.add(codigoTarea);
        return false;
    }

    // ---------------------------------------------------------------- RF07
    /** Tareas pendientes que tienen al menos un prerrequisito sin completar. */
    public List<String> tareasEnEspera() {
        List<String> bloqueadas = new ArrayList<>();
        for (Tarea tarea : proyecto.getMapaTareas().values()) {
            if (!tarea.isCompletada() && tieneRequisitoPendiente(tarea)) {
                bloqueadas.add(tarea.getCodigo());
            }
        }
        return bloqueadas;
    }

    private boolean tieneRequisitoPendiente(Tarea tarea) {
        for (String codigoRequisito : tarea.getRequisitos()) {
            if (!buscarTarea(codigoRequisito).isCompletada()) {
                return true;
            }
        }
        return false;
    }

    // ---------------------------------------------------------------- RF08
    public String armarReporte() {
        int completadas = 0;
        int pendientes = 0;
        for (Tarea tarea : proyecto.getMapaTareas().values()) {
            if (tarea.isCompletada()) {
                completadas++;
            } else {
                pendientes++;
            }
        }
        return "Completadas: " + completadas + " | Pendientes: " + pendientes
                + " | Bloqueadas: " + tareasEnEspera().size();
    }

    // ---------------------------------------------------------------- apoyo
    public Collection<Tarea> verTareas() {
        return proyecto.getMapaTareas().values();
    }

    public Tarea buscarTarea(String codigoTarea) {
        Tarea tarea = proyecto.getMapaTareas().get(codigoTarea);
        if (tarea == null) {
            throw new IllegalArgumentException("No existe la tarea " + codigoTarea + ".");
        }
        return tarea;
    }
}
