package Modelo;

import java.util.LinkedHashMap;
import java.util.Map;

/** Guarda las tareas del proyecto; cada tarea apunta a sus prerrequisitos por codigo (grafo dirigido). */
public class PlanProyecto {

    private final Map<String, Tarea> mapaTareas = new LinkedHashMap<>();

    public Map<String, Tarea> getMapaTareas() { return mapaTareas; }
}
