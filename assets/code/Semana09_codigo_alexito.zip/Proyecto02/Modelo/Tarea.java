package Modelo;

import java.util.ArrayList;
import java.util.List;

/** Una tarea del proyecto: codigo unico, descripcion, estado y las tareas que debe esperar. */
public class Tarea {

    private final String codigo;
    private final String descripcion;
    private boolean completada;
    private final List<String> listaRequisitos = new ArrayList<>();

    public Tarea(String codigo, String descripcion, boolean completada) {
        this.codigo = codigo;
        this.descripcion = descripcion;
        this.completada = completada;
    }

    public String getCodigo() { return codigo; }

    public String getDescripcion() { return descripcion; }

    public boolean isCompletada() { return completada; }

    public void setCompletada(boolean completada) { this.completada = completada; }

    public List<String> getRequisitos() { return listaRequisitos; }

    public String getEstado() { return completada ? "COMPLETADA" : "PENDIENTE"; }
}
