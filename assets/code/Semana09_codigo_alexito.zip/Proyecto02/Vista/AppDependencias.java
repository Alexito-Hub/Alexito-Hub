package Vista;

import DAO.GestorDependencias;
import Modelo.PlanProyecto;
import Modelo.Tarea;
import java.util.List;
import java.util.Scanner;

/** Menu de consola del Proyecto 02: pide los datos, llama al DAO y muestra los resultados. */
public class AppDependencias {

    private final Scanner entradaTeclado = new Scanner(System.in);
    private final GestorDependencias dao = new GestorDependencias(new PlanProyecto());

    public void iniciar() {
        int opcionMenu;
        do {
            imprimirMenu();
            opcionMenu = leerEntero("Opcion: ");
            try {
                switch (opcionMenu) {
                    case 1 -> opcionRegistrarTarea();
                    case 2 -> opcionVincularRequisito();
                    case 3 -> opcionDependenciasDirectas();
                    case 4 -> opcionDependenciasIndirectas();
                    case 5 -> opcionProfundidad();
                    case 6 -> opcionDetectarCiclo();
                    case 7 -> opcionTareasBloqueadas();
                    case 8 -> System.out.println(dao.armarReporte());
                    case 9 -> opcionCargarEjemplo();
                    case 0 -> System.out.println("Fin del programa.");
                    default -> System.out.println("Opcion no valida.");
                }
            } catch (IllegalArgumentException | IllegalStateException problema) {
                System.out.println("Error: " + problema.getMessage());
            }
        } while (opcionMenu != 0);
    }

    private void imprimirMenu() {
        System.out.println("\n=== DEPENDENCIAS DE TAREAS ===");
        System.out.println("[1] Registrar tarea          [2] Registrar dependencia");
        System.out.println("[3] Dependencias directas    [4] Dependencias indirectas");
        System.out.println("[5] Profundidad de cadena    [6] Detectar ciclos");
        System.out.println("[7] Tareas bloqueadas        [8] Reporte");
        System.out.println("[9] Cargar datos de ejemplo  [0] Salir");
    }

    private void opcionRegistrarTarea() {
        String codigoTarea = leerTexto("Codigo: ");
        String textoDescripcion = leerTexto("Descripcion: ");
        String respuestaEstado = leerTexto("Esta completada? (s/n): ");
        dao.crearTarea(codigoTarea, textoDescripcion, respuestaEstado.equalsIgnoreCase("s"));
        System.out.println("Tarea registrada: " + codigoTarea);
    }

    private void opcionVincularRequisito() {
        String codigoTarea = leerTexto("Tarea que depende: ");
        String codigoRequisito = leerTexto("Prerrequisito: ");
        dao.vincularRequisito(codigoTarea, codigoRequisito);
        System.out.println("Dependencia registrada: " + codigoTarea + " -> " + codigoRequisito);
    }

    private void opcionDependenciasDirectas() {
        String codigoTarea = leerTexto("Codigo de la tarea: ");
        System.out.println("Directas de " + codigoTarea + ": " + dao.requisitosDirectos(codigoTarea));
    }

    private void opcionDependenciasIndirectas() {
        String codigoTarea = leerTexto("Codigo de la tarea: ");
        System.out.println("Todas las dependencias de " + codigoTarea + ": " + dao.requisitosIndirectos(codigoTarea));
    }

    private void opcionProfundidad() {
        String codigoTarea = leerTexto("Codigo de la tarea: ");
        System.out.println("Profundidad maxima de " + codigoTarea + ": " + dao.nivelMaximo(codigoTarea));
    }

    private void opcionDetectarCiclo() {
        List<String> rutaDelCiclo = dao.buscarRutaCiclo();
        System.out.println(rutaDelCiclo.isEmpty() ? "Sin ciclos: la planificacion es valida." : "CICLO detectado: " + rutaDelCiclo);
    }

    private void opcionTareasBloqueadas() {
        List<String> tareasEnEspera = dao.tareasEnEspera();
        System.out.println(tareasEnEspera.isEmpty() ? "No hay tareas bloqueadas." : "Bloqueadas: " + tareasEnEspera);
    }

    /** Carga el proyecto de ejemplo del enunciado (autenticacion, clientes, inventario, ventas...). */
    private void opcionCargarEjemplo() {
        dao.crearTarea("AUT-01", "Autenticacion", true);
        dao.crearTarea("CLI-02", "Modulo de clientes", true);
        dao.crearTarea("INV-03", "Modulo de inventario", false);
        dao.crearTarea("VEN-04", "Modulo de ventas", false);
        dao.crearTarea("REP-05", "Modulo de reportes", false);
        dao.crearTarea("PRU-06", "Pruebas de integracion", false);
        dao.vincularRequisito("CLI-02", "AUT-01");
        dao.vincularRequisito("INV-03", "AUT-01");
        dao.vincularRequisito("VEN-04", "CLI-02");
        dao.vincularRequisito("VEN-04", "INV-03");
        dao.vincularRequisito("REP-05", "VEN-04");
        dao.vincularRequisito("PRU-06", "VEN-04");
        dao.vincularRequisito("PRU-06", "REP-05");
        System.out.println("Datos de ejemplo cargados: " + dao.verTareas().size() + " tareas.");
        for (Tarea tarea : dao.verTareas()) {
            System.out.println("  " + tarea.getCodigo() + " " + tarea.getDescripcion() + " [" + tarea.getEstado() + "]");
        }
    }

    private String leerTexto(String textoPregunta) {
        System.out.print(textoPregunta);
        return entradaTeclado.nextLine().trim();
    }

    private int leerEntero(String textoPregunta) {
        try {
            return Integer.parseInt(leerTexto(textoPregunta));
        } catch (NumberFormatException errorNumero) {
            return -1;
        }
    }
}
