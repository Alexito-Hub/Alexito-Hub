package Vista;

/** Punto de entrada del Proyecto 02. */
public class Inicio {

    public static void main(String[] args) {
        new AppDependencias().iniciar();
    }
}
