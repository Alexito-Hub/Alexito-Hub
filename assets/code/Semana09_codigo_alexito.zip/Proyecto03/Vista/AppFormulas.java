package Vista;

import DAO.CalculadoraFormulas;
import Modelo.Formula;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/** Menu de consola del Proyecto 03: varias evaluaciones en una misma sesion. */
public class AppFormulas {

    private final Scanner entradaTeclado = new Scanner(System.in);
    private final CalculadoraFormulas dao = new CalculadoraFormulas();
    private final List<Formula> historialFormulas = new ArrayList<>();

    public void iniciar() {
        int opcionMenu;
        do {
            System.out.println("\n=== EVALUADOR DE REGLAS COMERCIALES ===");
            System.out.println("[1] Evaluar expresion   [2] Precio final Pf = (Pb - D) x (1 + I)");
            System.out.println("[3] Validar expresion   [4] Historial de la sesion   [0] Salir");
            opcionMenu = leerEntero("Opcion: ");
            switch (opcionMenu) {
                case 1 -> calcularYMostrar(leerTexto("Expresion: "));
                case 2 -> opcionPrecioFinal();
                case 3 -> opcionValidar();
                case 4 -> opcionHistorial();
                case 0 -> System.out.println("Fin del programa.");
                default -> System.out.println("Opcion no valida.");
            }
        } while (opcionMenu != 0);
    }

    private void calcularYMostrar(String textoFormula) {
        Formula formula = new Formula(textoFormula);
        try {
            dao.calcular(formula);
            historialFormulas.add(formula);
            System.out.println("Expresion: " + formula.getTextoFormula());
            System.out.println("Resultado: " + formula.getResultado());
        } catch (IllegalArgumentException errorFormula) {
            System.out.println("Error: " + errorFormula.getMessage());
        }
    }

    private void opcionPrecioFinal() {
        String precioBaseTexto = leerTexto("Precio base Pb: ");
        String descuentoMonetario = leerTexto("Descuento D: ");
        String tasaImpuesto = leerTexto("Tasa de impuesto I (ej. 0.18): ");
        calcularYMostrar("(" + precioBaseTexto + "-" + descuentoMonetario + ")*(1+" + tasaImpuesto + ")");
    }

    private void opcionValidar() {
        String motivoRechazo = dao.comprobar(leerTexto("Expresion a validar: "));
        System.out.println(motivoRechazo == null ? "Expresion valida." : "Expresion invalida: " + motivoRechazo);
    }

    private void opcionHistorial() {
        if (historialFormulas.isEmpty()) {
            System.out.println("Todavia no hay evaluaciones en esta sesion.");
        }
        for (int indice = 0; indice < historialFormulas.size(); indice++) {
            Formula formula = historialFormulas.get(indice);
            System.out.println((indice + 1) + ") " + formula.getTextoFormula() + " = " + formula.getResultado());
        }
    }

    private String leerTexto(String textoPregunta) {
        System.out.print(textoPregunta);
        return entradaTeclado.nextLine().trim();
    }

    private int leerEntero(String textoPregunta) {
        try {
            return Integer.parseInt(leerTexto(textoPregunta));
        } catch (NumberFormatException errorNumero) {
            return -1;
        }
    }
}
