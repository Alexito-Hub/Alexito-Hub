package Vista;

/** Punto de entrada del Proyecto 03. */
public class Inicio {

    public static void main(String[] args) {
        new AppFormulas().iniciar();
    }
}
