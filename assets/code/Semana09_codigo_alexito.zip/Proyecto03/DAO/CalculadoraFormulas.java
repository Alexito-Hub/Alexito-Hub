package DAO;

import Modelo.Formula;
import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;

/**
 * Evaluador por descenso recursivo. Gramatica:
 *   expresion := termino  { (+|-) termino }
 *   termino   := factor   { (*|/) factor }
 *   factor    := numero | '(' expresion ')' | '-' factor
 * analizarSumasRestas() llama a analizarProductos(), analizarProductos() a analizarFactor() y analizarFactor() vuelve a llamar a analizarSumasRestas()
 * dentro de los parentesis: asi se evaluan las expresiones anidadas.
 */
public class CalculadoraFormulas {

    private String formulaSinEspacios;
    private int posicionLectura;

    public void calcular(Formula formula) {
        formulaSinEspacios = formula.getTextoFormula().replace(" ", "");
        posicionLectura = 0;
        if (formulaSinEspacios.isEmpty()) {
            throw new IllegalArgumentException("La expresion esta vacia.");
        }
        BigDecimal resultado = analizarSumasRestas();
        if (posicionLectura < formulaSinEspacios.length()) {
            char simboloSobrante = formulaSinEspacios.charAt(posicionLectura);
            throw new IllegalArgumentException(simboloSobrante == ')'
                    ? "Parentesis de cierre sin apertura en la posicion " + (posicionLectura + 1) + "."
                    : "Simbolo inesperado '" + simboloSobrante + "' en la posicion " + (posicionLectura + 1) + ".");
        }
        formula.setResultado(resultado.setScale(2, RoundingMode.HALF_UP));
    }

    /** RF10: valida sin guardar nada; devuelve null si la expresion es correcta o el motivo del error. */
    public String comprobar(String textoFormula) {
        try {
            calcular(new Formula(textoFormula));
            return null;
        } catch (IllegalArgumentException errorFormula) {
            return errorFormula.getMessage();
        }
    }

    /** Procesa sumas y restas. */
    private BigDecimal analizarSumasRestas() {
        BigDecimal valorParcial = analizarProductos();
        while (haySimbolo('+') || haySimbolo('-')) {
            char simboloOperacion = formulaSinEspacios.charAt(posicionLectura++);
            BigDecimal siguienteProducto = analizarProductos();
            valorParcial = (simboloOperacion == '+') ? valorParcial.add(siguienteProducto)
                                          : valorParcial.subtract(siguienteProducto);
        }
        return valorParcial;
    }

    /** Procesa multiplicaciones y divisiones (tienen mas precedencia que + y -). */
    private BigDecimal analizarProductos() {
        BigDecimal valorParcial = analizarFactor();
        while (haySimbolo('*') || haySimbolo('/')) {
            char simboloOperacion = formulaSinEspacios.charAt(posicionLectura++);
            BigDecimal siguienteValor = analizarFactor();
            if (simboloOperacion == '*') {
                valorParcial = valorParcial.multiply(siguienteValor);
            } else {
                if (siguienteValor.signum() == 0) {
                    throw new IllegalArgumentException("Division por cero.");
                }
                valorParcial = valorParcial.divide(siguienteValor, MathContext.DECIMAL64);
            }
        }
        return valorParcial;
    }

    /** Procesa numeros, signo negativo y parentesis; dentro del parentesis vuelve a llamar a analizarSumasRestas(). */
    private BigDecimal analizarFactor() {
        if (posicionLectura >= formulaSinEspacios.length()) {
            throw new IllegalArgumentException(
                    "La expresion termina antes de tiempo: falta un operando.");
        }
        char simboloActual = formulaSinEspacios.charAt(posicionLectura);
        if (simboloActual == '-') {
            posicionLectura++;
            return analizarFactor().negate();
        }
        if (simboloActual == '(') {
            int posicionApertura = posicionLectura + 1;
            posicionLectura++;
            BigDecimal valorDentroParentesis = analizarSumasRestas();
            if (!haySimbolo(')')) {
                throw new IllegalArgumentException(
                        "Parentesis sin cerrar (abierto en la posicion "
                        + posicionApertura + ").");
            }
            posicionLectura++;
            return valorDentroParentesis;
        }
        return leerNumero();
    }

    private BigDecimal leerNumero() {
        int posicionInicioNumero = posicionLectura;
        while (posicionLectura < formulaSinEspacios.length()
                && (Character.isDigit(formulaSinEspacios.charAt(posicionLectura)) || formulaSinEspacios.charAt(posicionLectura) == '.')) {
            posicionLectura++;
        }
        if (posicionInicioNumero == posicionLectura) {
            throw new IllegalArgumentException("Se esperaba un numero en la posicion " + (posicionLectura + 1)
                    + " y se encontro '" + formulaSinEspacios.charAt(posicionLectura) + "'.");
        }
        try {
            return new BigDecimal(formulaSinEspacios.substring(posicionInicioNumero, posicionLectura));
        } catch (NumberFormatException errorNumeroMalFormado) {
            throw new IllegalArgumentException("Numero mal formado: " + formulaSinEspacios.substring(posicionInicioNumero, posicionLectura) + ".");
        }
    }

    private boolean haySimbolo(char simboloBuscado) {
        return posicionLectura < formulaSinEspacios.length() && formulaSinEspacios.charAt(posicionLectura) == simboloBuscado;
    }
}
