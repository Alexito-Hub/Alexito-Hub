package Modelo;

import java.math.BigDecimal;

/** Una expresion comercial escrita por el usuario y el resultado de evaluarla. */
public class Formula {

    private final String textoFormula;
    private BigDecimal resultado;

    public Formula(String textoFormula) {
        this.textoFormula = textoFormula;
    }

    public String getTextoFormula() { return textoFormula; }

    public BigDecimal getResultado() { return resultado; }

    public void setResultado(BigDecimal resultado) { this.resultado = resultado; }
}
