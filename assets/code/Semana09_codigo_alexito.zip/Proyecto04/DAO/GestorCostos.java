package DAO;

import Modelo.Parte;
import Modelo.Articulo;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Calcula el costo de fabricacion recorriendo recursivamente la estructura jerarquica de cada producto. */
public class GestorCostos {

    private final Map<String, Articulo> catalogo = new LinkedHashMap<>();

    // ------------------------------------------------------ RF01, RF02, RF09
    public void crearArticulo(String codigo, String nombre, BigDecimal costoPropio) {
        if (codigo.isEmpty() || nombre.isEmpty()) {
            throw new IllegalArgumentException("El codigo y el nombre no pueden estar vacios.");
        }
        if (costoPropio.signum() < 0) {
            throw new IllegalArgumentException("El costo no puede ser negativo.");
        }
        if (catalogo.containsKey(codigo)) {
            throw new IllegalArgumentException("Ya existe el producto " + codigo + ".");
        }
        catalogo.put(codigo, new Articulo(codigo, nombre, costoPropio));
    }

    // ------------------------------------------------------ RF03, RF04, RF08, RF09
    public void agregarParte(String codigoArticulo, String codigoParte, int unidadesRequeridas) {
        Articulo articulo = buscarArticulo(codigoArticulo);
        buscarArticulo(codigoParte);
        if (unidadesRequeridas <= 0) {
            throw new IllegalArgumentException("La cantidad debe ser mayor que cero.");
        }
        if (codigoArticulo.equals(codigoParte)) {
            throw new IllegalArgumentException("Un producto no puede contenerse a si mismo.");
        }
        if (incluyeParte(codigoParte, codigoArticulo)) {
            throw new IllegalArgumentException("Ciclo: " + codigoParte + " ya contiene a " + codigoArticulo + ".");
        }
        articulo.getPartes().add(new Parte(codigoParte, unidadesRequeridas));
    }

    /** RF08: true si {@code codigoBuscado} aparece en cualquier nivel dentro de {@code codigoRaiz}. */
    public boolean incluyeParte(String codigoArticuloRaiz, String codigoParteBuscada) {
        for (Parte parte : buscarArticulo(codigoArticuloRaiz).getPartes()) {
            if (parte.codigoParte().equals(codigoParteBuscada)
                    || incluyeParte(parte.codigoParte(), codigoParteBuscada)) {
                return true;
            }
        }
        return false;
    }

    // ------------------------------------------------------ RF05
    /** Costo total = costo propio + suma de (cantidad x costo total) de cada componente. */
    public BigDecimal costoDeFabricacion(String codigoArticulo) {
        Articulo articulo = buscarArticulo(codigoArticulo);
        return sumarPartes(articulo.getPartes(), 0, articulo.getCostoPropio());
    }

    /**
     * Recursividad anidada: costoDeFabricacion(...) (llamada interior) calcula el costo de un componente y su
     * resultado, multiplicado por la cantidad, se usa dentro del argumento de la llamada exterior.
     */
    private BigDecimal sumarPartes(List<Parte> partes, int indice, BigDecimal costoAcumulado) {
        if (indice == partes.size()) {
            return costoAcumulado;                                   // caso base: no quedan componentes
        }
        Parte parte = partes.get(indice);
        return sumarPartes(partes, indice + 1,
                costoAcumulado.add(costoDeFabricacion(parte.codigoParte())
                        .multiply(BigDecimal.valueOf(parte.unidadesRequeridas()))));
    }

    // ------------------------------------------------------ RF06
    /** Desglose por niveles: cada nivel se sangra con dos espacios mas. */
    public String mostrarDesglose(String codigoArticulo, int cantidad, int nivel) {
        Articulo articulo = buscarArticulo(codigoArticulo);
        StringBuilder textoDesglose = new StringBuilder();
        textoDesglose.append("  ".repeat(nivel)).append(cantidad).append(" x ").append(articulo.getNombre())
                .append(" (").append(codigoArticulo).append(")  costo total ").append(costoDeFabricacion(codigoArticulo)
                        .multiply(BigDecimal.valueOf(cantidad)).setScale(2)).append('\n');
        for (Parte parte : articulo.getPartes()) {
            textoDesglose.append(mostrarDesglose(parte.codigoParte(), parte.unidadesRequeridas(), nivel + 1));
        }
        return textoDesglose.toString();
    }

    // ------------------------------------------------------ RF07
    /** Componentes usados directamente por dos o mas productos distintos. */
    public Map<String, List<String>> partesCompartidas() {
        Map<String, List<String>> usadaEn = new LinkedHashMap<>();
        for (Articulo articulo : catalogo.values()) {
            for (Parte parte : articulo.getPartes()) {
                usadaEn.computeIfAbsent(parte.codigoParte(), c -> new ArrayList<>()).add(articulo.getCodigo());
            }
        }
        usadaEn.values().removeIf(articulos -> articulos.size() < 2);
        return usadaEn;
    }

    // ------------------------------------------------------ RF10
    /** Productos terminados: los que no son componente de ningun otro. */
    public String armarReporte() {
        StringBuilder textoReporte = new StringBuilder();
        for (Articulo articulo : catalogo.values()) {
            if (!esParteDeOtro(articulo.getCodigo())) {
                textoReporte.append(articulo.getNombre()).append(" (").append(articulo.getCodigo())
                        .append("): S/ ").append(costoDeFabricacion(articulo.getCodigo()).setScale(2)).append('\n');
            }
        }
        return textoReporte.toString();
    }

    private boolean esParteDeOtro(String codigoArticulo) {
        for (Articulo articulo : catalogo.values()) {
            for (Parte parte : articulo.getPartes()) {
                if (parte.codigoParte().equals(codigoArticulo)) {
                    return true;
                }
            }
        }
        return false;
    }

    // ------------------------------------------------------ apoyo
    public Collection<Articulo> verArticulos() { return catalogo.values(); }

    public Articulo buscarArticulo(String codigoArticulo) {
        Articulo articulo = catalogo.get(codigoArticulo);
        if (articulo == null) {
            throw new IllegalArgumentException("No existe el producto " + codigoArticulo + ".");
        }
        return articulo;
    }
}
