package Modelo;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/** Producto o componente. costoUnitario es lo que cuesta por si solo (compra o ensamblaje), sin sus partes. */
public class Articulo {

    private final String codigo;
    private final String nombre;
    private final BigDecimal costoPropio;
    private final List<Parte> partes = new ArrayList<>();

    public Articulo(String codigo, String nombre, BigDecimal costoPropio) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.costoPropio = costoPropio;
    }

    public String getCodigo() { return codigo; }

    public String getNombre() { return nombre; }

    public BigDecimal getCostoPropio() { return costoPropio; }

    public List<Parte> getPartes() { return partes; }
}
