package Modelo;

/** Relacion "articulo contiene parte": el codigo de la parte y cuantas unidades se necesitan (record de Java 17). */
public record Parte(String codigoParte, int unidadesRequeridas) {
}
