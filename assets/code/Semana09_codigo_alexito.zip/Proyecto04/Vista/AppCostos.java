package Vista;

import DAO.GestorCostos;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/** Menu de consola del Proyecto 04. */
public class AppCostos {

    private final Scanner entradaTeclado = new Scanner(System.in);
    private final GestorCostos dao = new GestorCostos();

    public void iniciar() {
        int opcionMenu;
        do {
            System.out.println("\n=== COSTOS DE PRODUCTOS COMPUESTOS ===");
            System.out.println("[1] Registrar producto     [2] Agregar componente");
            System.out.println("[3] Costo total            [4] Desglose por niveles");
            System.out.println("[5] Componentes compartidos [6] Reporte de costos");
            System.out.println("[9] Cargar datos de ejemplo [0] Salir");
            opcionMenu = leerEntero("Opcion: ");
            try {
                switch (opcionMenu) {
                    case 1 -> opcionCrearArticulo();
                    case 2 -> opcionAgregarParte();
                    case 3 -> opcionCostoTotal();
                    case 4 -> opcionDesglose();
                    case 5 -> opcionPartesCompartidas();
                    case 6 -> System.out.print(dao.armarReporte());
                    case 9 -> opcionCargarEjemplo();
                    case 0 -> System.out.println("Fin del programa.");
                    default -> System.out.println("Opcion no valida.");
                }
            } catch (IllegalArgumentException | ArithmeticException problema) {
                System.out.println("Error: " + problema.getMessage());
            }
        } while (opcionMenu != 0);
    }

    private void opcionCrearArticulo() {
        String codigoArticulo = leerTexto("Codigo: ");
        String nombreArticulo = leerTexto("Nombre: ");
        BigDecimal costoPropio = leerDecimal("Costo unitario (S/): ");
        dao.crearArticulo(codigoArticulo, nombreArticulo, costoPropio);
        System.out.println("Producto registrado: " + codigoArticulo);
    }

    private void opcionAgregarParte() {
        String codigoArticulo = leerTexto("Producto: ");
        String codigoParte = leerTexto("Componente: ");
        int unidadesRequeridas = leerEntero("Cantidad requerida: ");
        dao.agregarParte(codigoArticulo, codigoParte, unidadesRequeridas);
        System.out.println(codigoArticulo + " ahora contiene " + unidadesRequeridas + " x " + codigoParte);
    }

    private void opcionCostoTotal() {
        String codigoArticulo = leerTexto("Codigo del producto: ");
        System.out.println("Costo total de " + codigoArticulo + ": S/ " + dao.costoDeFabricacion(codigoArticulo).setScale(2));
    }

    private void opcionDesglose() {
        String codigoArticulo = leerTexto("Codigo del producto: ");
        System.out.print(dao.mostrarDesglose(codigoArticulo, 1, 0));
    }

    private void opcionPartesCompartidas() {
        Map<String, List<String>> partesComunes = dao.partesCompartidas();
        if (partesComunes.isEmpty()) {
            System.out.println("No hay componentes compartidos.");
        }
        partesComunes.forEach((parte, articulos) ->
                System.out.println(parte + " lo usan: " + articulos));
    }

    /** Carga el ejemplo: computador y servidor comparten placa, memoria y fuente. */
    private void opcionCargarEjemplo() {
        dao.crearArticulo("CHIP-06", "Chip procesador", new BigDecimal("25.00"));
        dao.crearArticulo("CAPA-07", "Capacitor", new BigDecimal("0.50"));
        dao.crearArticulo("RAM-03", "Modulo de memoria", new BigDecimal("60.00"));
        dao.crearArticulo("FUEN-05", "Fuente de alimentacion", new BigDecimal("45.00"));
        dao.crearArticulo("PLAC-02", "Placa electronica", new BigDecimal("40.00"));
        dao.crearArticulo("SSD-04", "Unidad de almacenamiento", new BigDecimal("30.00"));
        dao.crearArticulo("PC-01", "Computador", new BigDecimal("50.00"));
        dao.crearArticulo("SERV-08", "Servidor", new BigDecimal("80.00"));
        dao.agregarParte("PLAC-02", "CHIP-06", 1);
        dao.agregarParte("PLAC-02", "CAPA-07", 20);
        dao.agregarParte("SSD-04", "CHIP-06", 1);
        dao.agregarParte("PC-01", "PLAC-02", 1);
        dao.agregarParte("PC-01", "RAM-03", 2);
        dao.agregarParte("PC-01", "SSD-04", 1);
        dao.agregarParte("PC-01", "FUEN-05", 1);
        dao.agregarParte("SERV-08", "PLAC-02", 2);
        dao.agregarParte("SERV-08", "RAM-03", 8);
        dao.agregarParte("SERV-08", "FUEN-05", 2);
        System.out.println("Datos de ejemplo cargados: " + dao.verArticulos().size() + " productos.");
    }

    private String leerTexto(String textoPregunta) {
        System.out.print(textoPregunta);
        return entradaTeclado.nextLine().trim();
    }

    private int leerEntero(String textoPregunta) {
        try {
            return Integer.parseInt(leerTexto(textoPregunta));
        } catch (NumberFormatException errorNumero) {
            return -1;
        }
    }

    private BigDecimal leerDecimal(String textoPregunta) {
        try {
            return new BigDecimal(leerTexto(textoPregunta));
        } catch (NumberFormatException errorNumero) {
            throw new IllegalArgumentException("El costo debe ser un numero.");
        }
    }
}
