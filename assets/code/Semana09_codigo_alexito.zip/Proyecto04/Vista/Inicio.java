package Vista;

/** Punto de entrada del Proyecto 04. */
public class Inicio {

    public static void main(String[] args) {
        new AppCostos().iniciar();
    }
}
